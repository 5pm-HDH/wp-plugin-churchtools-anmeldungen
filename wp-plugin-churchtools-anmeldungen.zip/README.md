# Wordpress-Plugin für ChurchTools-Anmeldung

Mit diesem Wordpress-Plugin kannst du das von ChurchTools zur Verfügung gestellte iFrame für die Anmeldungen ersetzen durch einen eigenen Template-basierten Ansatz.

**Bibliotheken:**

* [CT-Api Wrapper](https://github.com/5pm-HDH/churchtools-api) für den Datentransfer
* [Twig](https://twig.symfony.com/) als mögliche Template-Engine
